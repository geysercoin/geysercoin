EN

How to troubleshoot synchronization problems with your GeyserCoin wallet 

1. If the balance of the wallet is not displayed correctly, run the shortcut
"geysercoin-qt.exe -rescan"

2. If the synchronization of the blocks is taking too long, launch the shortcut
"geysercoin-qt.exe -reindex"

3. If there are no connections, launch the shortcut
"geysercoin-qt.exe -addnode"

Please make sure that your version of the wallet matches the version listed on the site!
Latest version v2.1.0.2-g07o2018y

RU

Как устранить проблемы синхронизации с вашим кошельком GeyserCoin

1. Если баланс кошелька отображается неправильно, запустите ярлык
"geysercoin-qt.exe -rescan"

2. Если синхронизация блоков занимает слишком много времени, запустите ярлык
"geysercoin-qt.exe -reindex"

3. Если соединений нет, запустите ярлык
"geysercoin-qt.exe -addnode"

Убедитесь, что ваша версия кошелька соответствует версии, указанной на сайте!
Последняя версия v2.1.0.2-g07o2018y